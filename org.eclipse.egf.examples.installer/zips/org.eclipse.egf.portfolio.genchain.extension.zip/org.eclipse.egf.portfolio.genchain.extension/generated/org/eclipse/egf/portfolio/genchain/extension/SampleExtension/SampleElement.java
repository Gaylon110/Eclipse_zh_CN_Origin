/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.eclipse.egf.portfolio.genchain.extension.SampleExtension;

import org.eclipse.egf.portfolio.genchain.generationChain.EcoreElement;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Sample Element</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.egf.portfolio.genchain.extension.SampleExtension.SampleExtensionPackage#getSampleElement()
 * @model
 * @generated
 */
public interface SampleElement extends EcoreElement {
} // SampleElement
