package org.eclipse.emf.parsley.examples.eclipse4.parsleypart;

import org.eclipse.emf.parsley.EmfParsleyGuiceModule;
import org.eclipse.ui.plugin.AbstractUIPlugin;

/**
 * org.eclipse.emf.parsley.examples.eclipse4.parsleypart Emf Components Dsl Module file
 */
@SuppressWarnings("all")
public class ParsleypartEmfParsleyGuiceModule extends EmfParsleyGuiceModule {
  public ParsleypartEmfParsleyGuiceModule(final AbstractUIPlugin plugin) {
    super(plugin);
  }
}
