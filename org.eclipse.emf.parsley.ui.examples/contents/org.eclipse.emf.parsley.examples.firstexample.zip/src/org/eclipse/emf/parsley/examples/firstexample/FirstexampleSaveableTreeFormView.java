package org.eclipse.emf.parsley.examples.firstexample;

public class FirstexampleSaveableTreeFormView extends org.eclipse.emf.parsley.views.SaveableTreeFormView {
	
}
